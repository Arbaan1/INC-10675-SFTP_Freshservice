const { Freshservice } = require("./core/service/freshservice")
const createRecurringScheduleForEscalation = require("./core/service/schedulerServices")
const freshservice = new Freshservice()
exports = {
    onAppInstallHandler: async function(payload) {
        console.log("OnAppInstallHandler", payload);
        await createRecurringScheduleForEscalation(
            `createRequesterFromCsvFile`, //name should be unique and there is a char limit
            {
              //payload has been sent empty
              payload,
            },
            // new Date(new Date().getTime() + (24 * 60 * 60 * 1000)) //Schedule Start from after 24 hours..
            new Date(new Date().getTime() +  6 * 6000) //Schedule Start from an hour..
          );
            renderData();
    },
    onExternalEventHandler: async function(payload) {
      console.log("onExternalEventHandler", payload);
      // const sftpData = await freshservice.activeRequester(payload)
      // console.log("SFTPDATA", sftpData);
  },
  onScheduledEventHandler: async function (payload) {
      console.log("onScheduledEventHandler", payload);
      // const sftpData = await freshservice.activeRequester(payload)
      const sftpData = await freshservice.subscriptionMiddleware(payload)
    },
  

}