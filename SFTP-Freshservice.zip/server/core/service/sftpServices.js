// const Client = require("ssh2-sftp-client");
// const csv = require("csvtojson");
// class sftpServer {
// 	async getExcelFile() {
// 		const config = {
// 			host: "sftp-east.netsmartcloud.com",
// 			port: 22,
// 			username: "sftpfreshworks@ssl_il_freshworks",
// 			password: "n9MBx1c3W4",
// 			algorithms: {
// 				cipher: ["aes256-cbc"],
// 			},
// 		};
// 		try {
// 			let sftp = new Client();
// 			const connection = await sftp.connect(config);
// 			const listItems = await sftp.list("/");
// 			const downloadeCsvFiles = await sftp.get(`/${listItems[0].name}`);
// 			let jsonArray = [];
// 			const convertCsvToJson = await csv()
// 				.fromString(downloadeCsvFiles.toString())
// 				.subscribe((jsonObj) => {
// 					jsonArray.push(jsonObj);
// 				});
// 			console.log("convertCsvToJson==========>", convertCsvToJson);
// 			const endSftpConnection = await connection.end();
//             return convertCsvToJson;
// 		} catch (error) {
// 			console.log("error accessing file", error);
// 		}
// 	}
// }
// exports.sftpServer = sftpServer;