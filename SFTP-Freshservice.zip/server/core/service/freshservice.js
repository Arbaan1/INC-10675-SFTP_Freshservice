const { FreshserviceProxy } = require("../proxy/freshserviceProxy");
const _ = require("lodash");
const { sftpServer } = require("./sftpServices");
class Freshservice {
	async subscriptionMiddleware(payload) {
		const headers = {
			"Content-Type": "application/json",
		};
		const iparams = payload.iparams;
		const options = {
			header: headers,
			body: JSON.stringify({
				fs_apikey: iparams.fs_apikey,
				fs_domain: iparams.fs_domain,
				sftp_host: iparams.sftp_domain,
				sftp_username: iparams.sftp_username,
				sftp_password: iparams.sftp_password,
				fiel_mapping_values: iparams.fieldMappingValues,
			}),
		};
		const middlewareUrl = `https://us-central1-fw-integrations.cloudfunctions.net/SFTP-Freshservice-Middleware/sftpwithfreshservice`;

		try {
			const subcriptionResponse = await $request.post(middlewareUrl, options);
			console.log("Subcription response", subcriptionResponse);
		} catch (error) {
			console.log("Subcription error", error);
		}
	}
}
exports.Freshservice = Freshservice;
