const DAYJS = require("dayjs");

const createRecurringScheduleForEscalation = async(
    nameOfSchedule,
    paylodForSchedule,
    timeOfSchedule
) => {
    console.log("payload for schedule", paylodForSchedule.payload.iparams);
    $schedule
        .create({
            name: nameOfSchedule,
            data: { isSyncSchedule: true },
            schedule_at: timeOfSchedule,
            repeat: {
                time_unit: "hours",
                frequency: 24,
            },
        })
        .then(
            function(data) {
                console.log("Subscription schedule created successfully", data);
            },
            function(err) {
                console.log("Create Scheduled error", err);
            }
        );
};
exports = createRecurringScheduleForEscalation;