const axios = require("axios");
const btoa = require("btoa");

class FreshserviceProxy {
	static createAxiosInstance(fs_domain, fs_apikey) {
		// console.log("Getting apikey", fs_domain, fs_apikey);
		return axios.create({
			baseURL: `https://${fs_domain}/api/v2/`, //  url format domain.freshteam.com
			headers: {
				"Content-Type": "application/json",
				Authorization: "Basic " + btoa(fs_apikey),
			},
		});
	}

	constructor(iparams) {
		this.freshserviceRequest = FreshserviceProxy.createAxiosInstance(
			iparams.fs_domain,
			iparams.fs_apikey
		);
	}

	async searchEntity(email = undefined, name = undefined) {
		// console.log("Getting email in proxy", email);
		try {
			let url = "";
			if (email) {
				url = `requesters?query="primary_email:%27${email}%27"`;
			} else if (name) {
				url = `requesters?query="name:%27${name}%27"`;
			}
			// console.log("URL", url);
			const emailDetails = await this.freshserviceRequest.get(url);
			// console.log("emailDetails", emailDetails);
			return emailDetails.data;
		} catch (err) {
			console.log("Error details", err);
		}
	}
	async createEntity(iparams, body) {
		try {
			var config = {
				method: "post",
				url: `https://${iparams.fs_domain}/api/v2/requesters`,
				headers: {
					"Content-Type": "application/json",
					Authorization: "Basic " + btoa(iparams.fs_apikey),
				},
				data: body,
			};
			// const url = `requesters`;
			const createRequester = await axios(config);
			// const createRequester = await this.freshserviceRequest.post(url, config)
			// console.log("createRequester", createRequester);
			return createRequester.data;
		} catch (err) {
			console.log(" createRequester Error details", err);
		}
	}
	async updateEntity(iparams, requesterId, body) {
		console.log("updateRequester");
		try {
			console.log("iparams", iparams);
			console.log("requesterId", requesterId);
			console.log("body", body);

			var config = {
				method: "put",
				url: `https://${iparams.fs_domain}/api/v2/requesters/${requesterId}`,
				headers: {
					"Content-Type": "application/json",
					Authorization: "Basic " + btoa(iparams.fs_apikey),
				},
				data: JSON.stringify(body),
			};
			const updateRequester = await axios(config);
			return updateRequester.data;
		} catch (err) {
			console.log("updateRequester Error details", err);
		}
	}
	async deleteEntity(requesterId) {
		try {
			const url = `requesters/${requesterId}`;
			// console.log("URL", url);
			const deleteRequester = await this.freshserviceRequest.delete(url);
			// console.log("deleteRequester", deleteRequester);
			return deleteRequester.data;
		} catch (err) {
			console.log("deleteRequester Error details", err);
		}
	}
}
exports.FreshserviceProxy = FreshserviceProxy;
