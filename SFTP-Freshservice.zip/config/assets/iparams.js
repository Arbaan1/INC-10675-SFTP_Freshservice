function httpRequests(authInfo) {
	this.domain = authInfo.domain;
	this.fs_apikey = authInfo.fs_apikey;
	this.sftp_domain = authInfo.sftp_domain;
	this.sftp_username = authInfo.sftp_username;
	this.sftp_password = authInfo.sftp_password;
	this.fsEndpoints = {
		// getTicketFields: "/api/v2/ticket_form_fields",
		getRequesterFields: "/api/v2/requester_fields",
	};
	this.sftpEndPoints = {
		getSftpAuthPoint: "/ThinClient/WtmApiService.asmx/AuthUser",
	};
}
httpRequests.prototype.getRequesterFields = function () {
	var url = "https://" + this.domain + this.fsEndpoints.getRequesterFields;
	var headers = {
		"Content-Type": "application/json",
		Authorization: "Basic " + btoa(this.fs_apikey),
	};
	return client.request.get(url, { headers });
};
httpRequests.prototype.getSftpAuthPoint = function () {
	const sftpUrl = `https://${this.sftp_domain}${this.sftpEndPoints.getSftpAuthPoint}`;
	const options = {
		headers: {
			"Content-Type": "application/json",
		},
		body: JSON.stringify({
			user: this.sftp_username,
			pass: this.sftp_password,
			rememberMe: true,
			lang: "en-US",
		}),
	};
	return client.request.post(sftpUrl, options);
};
const switchTabPosition = (position) => {
	$("#Tabs").attr("active-tab-index", position);
};
function notify(message, type = "success") {
	var bgColor = type == "success" ? "#02b875" : "#DC161F";
	Toastify({
		text: message,
		duration: 2000,
		newWindow: true,
		close: true,
		gravity: "top",
		style: { background: bgColor },
		position: "right",
		stopOnFocus: true,
	}).showToast();
}
const prepopulate = async () => {
	const iparams = await client.iparams.get();
	const fieldMappingValues = iparams.fieldMappingValues;
	const fieldMappingValuesKeys = Object.keys(fieldMappingValues);
	for (i = 0; i < fieldMappingValuesKeys.length; i++) {
		if (fieldMappingValuesKeys[i] != "custom_fields") {
			$(`<div class="forward-mapping">
			<div class="freshservice-fields-dropdown">
			<select
				class="freshservice-fields"
				id="freshservice-fields${i}"
				onchange="changeEvent()"
			></select>
		</div>
		<div class="csv-fields-dropdown">
			<select class="csv-fields" id="csv-fields${i}" onchange="changeEvent()"></select>
		</div>
		<fw-button id="deletebtn" onclick="deleteRow(this)"
			>Remove</fw-button
		><br />
	</div>`).appendTo("#selectRow");
			loadPrepopulateOptions(iparams, i);
		}
	}
	if(fieldMappingValues.hasOwnProperty("custom_fields")){
		const fieldMappingCustomFieldsKeys = Object.keys(fieldMappingValues.custom_fields)
		for(j=0 ; j < fieldMappingCustomFieldsKeys.length; j++){
			$(`<div class="forward-mapping">
			<div class="freshservice-fields-dropdown">
			<select
				class="freshservice-fields"
				id="freshservice-fields-custom${j}"
				onchange="changeEvent()"
			></select>
		</div>
		<div class="csv-fields-dropdown">
			<select class="csv-fields" id="csv-fields-custom${j}" onchange="changeEvent()"></select>
		</div>
		<fw-button id="deletebtn" onclick="deleteRow(this)"
			>Remove</fw-button
		><br />
	</div>`).appendTo("#selectRow");
	loadPrepopulateCustomFieldOptions(iparams, j);
		}
	}
	changeEvent();
};
const loadPrepopulateCustomFieldOptions = (iparams, j) => {
	const requesters = ls.fsRequesterFields;
	const fieldMappingValues = iparams.fieldMappingValues;
	const customFields = fieldMappingValues.custom_fields;
	const fieldMappingCustomFieldsKeys = Object.keys(customFields)
	const fieldMappingCustomFieldsValues = Object.values(customFields)
	let options = `<option value="" disabled selected >select</option>`;
	let csvFields = `<option value="" disabled selected>select</option>`;
	requesters.forEach((element) => {
		options += `<option class="fs-option-tag" value="${element.name}">${element.label}</option>`;
	});
	$(`#freshservice-fields-custom${j}`).append(options);
	$(`#freshservice-fields-custom${j}`).val(fieldMappingCustomFieldsKeys[j])
	options = ``;
	ls.csvFields.forEach((fields) => {
		csvFields += `<option class="csv-option-tag" value="${fields.name}">${fields.label}</option>`;
	});
	$(`#csv-fields-custom${j}`).append(csvFields);
	$(`#csv-fields-custom${j}`).val(fieldMappingCustomFieldsValues[j])
	csvFields = ``;
}
const loadPrepopulateOptions = (iparams, i) => {
	const fieldMappingValues = iparams.fieldMappingValues;
	const valuesOfFieldMappingValues = Object.values(fieldMappingValues);
	let options = `<option value="" disabled selected>select</option>`;
	let csvFields = `<option value="" disabled selected>select</option>`;
	const requesters = ls.fsRequesterFields;
	const fieldMappingValuesKeys = Object.keys(fieldMappingValues);

	requesters.forEach((element) => {
		options += `<option class="fs-option-tag" value="${element.name}">${element.label}</option>`;
	});
	$(`#freshservice-fields${i}`).append(options);
	if(fieldMappingValuesKeys[i] == "work_phone_number"){
	$(`#freshservice-fields${i}`).val("phone")
	}else if(fieldMappingValuesKeys[i] == "primary_email"){
	$(`#freshservice-fields${i}`).val("email")
	}else{
		$(`#freshservice-fields${i}`).val(fieldMappingValuesKeys[i])
	}
	options = ``;
	ls.csvFields.forEach((fields) => {
		csvFields += `<option class="csv-option-tag" value="${fields.name}">${fields.label}</option>`;
	});
	$(`#csv-fields${i}`).append(csvFields);
	$(`#csv-fields${i}`).val(valuesOfFieldMappingValues[i])
	csvFields = ``;
};
function handleError(err) {
	$(".spinner-container").hide();
	console.log(err);
	if (err.status == 400) {
		notify(err.response.concat(" in Freshservice"), "error");
		return;
	}
	console.log(err.response);
	console.log(typeof err.response);
	if (err.status == 502) {
		notify("Freshservice Domain url is invaild", "error");
		return;
	}
	if (err.status == 503) {
		notify("SFTP Domain url is invaild", "error");
		return;
	}
	if (err.status == 401 || err.status == 403) {
		notify(" Freshservice invaild API_Key", "error");
		return;
	}
	if (err.status == 404) {
		notify(" Invaild url", "error");
		return;
	}
	if (err.status == 405) {
		console.log(err.response);
		if (err.response === "Login failed : Invalid Username or Password") {
			notify(" Invaild API Key", "error");
			return;
		} else if (
			err.response ===
			"There is no default host associated with the current user."
		) {
			notify(" Invaild User Name", "error");
			return;
		}
	}
}
