## MIDDLEWARE TO FETCH FLAT FILES FROM SFTP SERVER

This app collects data from the CSV and publish the same to the another app in fresh service app DB

### Files and Folders
    .
    ├── README.md                     A file for your future self and developer friends to learn about app
    ├── app                           Fetchs data from the SFTP server and show it in        the                               freshservice app DB
    │   ├── index.html                
    │   ├── scripts                   JavaScript to handle app's middleware logic
    │   │   └── app.js
    │   └── styles                    A folder of all the styles for app
    │       ├── images                A folder to put all the images
    │       │   ├── icon.svg
    │       │   └── rocket.svg
    │       └── style.css
    ├── config                        Freshservice validation and SFTP server validation
    │   └── iparams.json
    └── manifest.json                 A JSON file holding meta data for app to run on platform

Explore [more of app sample apps](https://community.developers.freshworks.com/t/freshworks-sample-apps/3604) on the Freshworks github respository.
